# Food App API

A RESTful backend for a food ordering platform built with Node.js, Express and MongoDB. This API supports user registration/login, role-based access control, CRUD operations for restaurants, categories and foods, cart-based order placement and admin-managed order status updates.

---

## Table of Contents
- [Features](#features)
- [Tech Stack](#tech-stack)
- [Getting Started](#getting-started)
- [Environment Variables](#environment-variables)
- [Install & Run](#install--run)
- [API Base URL](#api-base-url)
- [Key Endpoints](#key-endpoints)
- [Data Models (overview)](#data-models-overview)
- [Recommended Improvements](#recommended-improvements)
- [Contributing](#contributing)
- [License](#license)

---

## Features
- User registration and login with hashed passwords (bcrypt)
- JSON Web Token (JWT) authentication and middleware-protected routes
- Role-based access control (admin middleware for sensitive endpoints)
- CRUD for Restaurants, Foods, Categories
- Place orders (cart aggregation) and update order status (admin)
- Password reset and user profile management
- Request logging (morgan) and CORS enabled for cross-origin requests

## Tech Stack
- Node.js
- Express
- MongoDB (Mongoose)
- JWT for authentication
- bcryptjs for password hashing
- dotenv for environment configuration
- morgan for request logging

## Getting Started
These instructions help you run the project locally.

### Environment Variables
Create a `.env` file in the project root with at least the following variables:

```
MONGO_URL=<your-mongodb-connection-string>
JWT_SECRET=<a-secure-random-secret>
PORT=5000
```

### Install & Run
Install dependencies and start the server in development mode (nodemon recommended):

```powershell
npm install
npm run server
```

The server defaults to the port defined in `PORT` env or `5000`.

## API Base URL
All routes are mounted under `/api/v1`. Example base URL for local dev:

```
http://localhost:5000/api/v1
```

## Key Endpoints (summary)
Below are the most important endpoints. For each protected endpoint include the `Authorization: Bearer <token>` header.

- Auth
  - POST `/api/v1/auth/register` — Register a new user. Body: `{ userName, email, password, phone, address, answer }`
  - POST `/api/v1/auth/login` — Login and receive JWT. Body: `{ email, password }`

- User
  - GET `/api/v1/user/getUser` — Get current user info (protected)
  - PUT `/api/v1/user/updateUser` — Update profile (protected)
  - POST `/api/v1/user/updatePassword` — Change password (protected)
  - POST `/api/v1/user/resetPassword` — Reset password using `answer` (protected)
  - DELETE `/api/v1/user/deleteUser/:id` — Delete account (protected)

- Category
  - POST `/api/v1/category/create` — Create category (protected)
  - GET `/api/v1/category/getAll` — List categories
  - PUT `/api/v1/category/update/:id` — Update category (protected)
  - DELETE `/api/v1/category/delete/:id` — Delete category (protected)

- Restaurant
  - POST `/api/v1/resturant/create` — Create restaurant (protected)
  - GET `/api/v1/resturant/getAll` — List restaurants
  - GET `/api/v1/resturant/get/:id` — Get restaurant by id
  - DELETE `/api/v1/resturant/delete/:id` — Delete restaurant (protected)

- Food
  - POST `/api/v1/food/create` — Create food item (protected)
  - GET `/api/v1/food/getAll` — List all foods
  - GET `/api/v1/food/get/:id` — Get food by id
  - GET `/api/v1/food/getByResturant/:id` — Foods by restaurant id
  - PUT `/api/v1/food/update/:id` — Update food item (protected)
  - DELETE `/api/v1/food/delete/:id` — Delete food item (protected)
  - POST `/api/v1/food/placeorder` — Place order (protected)
  - POST `/api/v1/food/orderStatus/:id` — Update order status (protected, admin only)

### Example: Register & Login

Register a user:

```bash
curl -X POST http://localhost:5000/api/v1/auth/register \
  -H "Content-Type: application/json" \
  -d '{"userName":"Alice","email":"alice@example.com","password":"Pass1234","phone":"1234567890","address":"[\"Home\"]","answer":"pet"}'
```

Login to receive a token:

```bash
curl -X POST http://localhost:5000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"alice@example.com","password":"Pass1234"}'
```

Response contains `token` which must be sent in `Authorization: Bearer <token>` header for protected routes.

### Example: Place Order (protected)

```bash
curl -X POST http://localhost:5000/api/v1/food/placeorder \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer <TOKEN>" \
  -d '{"cart":[{"_id":"<foodId>","price":9.99}],"id":"<userId>"}'
```

## Data Models (overview)
- User: userName, email, password (hashed), phone, address, usertype (client|admin|vendor|driver), profile, answer
- Resturant: title, imageUrl, foods (array), coords (address + lat/lng), rating, etc.
- Foods: title, description, price, imageUrl, catgeory, resturnat (ObjectId ref), rating
- Orders: foods (refs), payment, buyer (ref), status (enum)

## Recommended Improvements
- Add request validation (express-validator or Joi) to protect inputs and return clearer errors.
- Add rate limiting (express-rate-limit) and request size limits to reduce abuse.
- Add unit and integration tests (Jest + Supertest) for auth and order flows.
- Add OpenAPI/Swagger documentation for easier API exploration and onboarding.
- Use a `.env.example` file with placeholder values and improve README with Postman collection or API spec.

## Contributing
Contributions are welcome. Please open issues for bugs or feature requests and create PRs with clear descriptions. Follow the existing code style (CommonJS, modular controllers/routes/models).

## License
This project is provided under the ISC license as declared in `package.json`.

---

If you'd like, I can also add a `.env.example` file, a short Postman collection (`app.http`) examples, or generate a minimal Swagger spec. Tell me which you'd like next.
