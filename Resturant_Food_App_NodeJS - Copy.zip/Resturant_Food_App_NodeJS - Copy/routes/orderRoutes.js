const express = require("express");

const authMiddleware = require("../middlewares/authMiddleware");
const {
  createOrderController,
  getAllOrderController,
  updateOrderController,
  deleteOrderController,
} = require("../controllers/orderController");

const router = express.Router();

//routes
// CREATE CAT
router.post("/create", authMiddleware, createOrderController);

//GET ALL CAT
router.get("/getAll", getAllOrderController);

// UPDATE CAT
router.put("/update/:id", authMiddleware, updateOrderController);

// DLEETE CAT
router.delete("/delete/:id", authMiddleware, deleteOrderController);

module.exports = router;
