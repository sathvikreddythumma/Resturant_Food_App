const orderModel = require("../models/orderModel");

// CREATE ORDER
const createOrderController = async (req, res) => {
  try {
    const { foods, payment, buyer, status } = req.body;
    //valdn
    if (!foods || foods.length === 0 || !payment || !buyer) {
      return res.status(500).send({
        success: false,
        message: "please provide order all fields",
      });
    }
    const newOrder = new orderModel({ foods, payment, buyer, status });
    await newOrder.save();
    res.status(201).send({
      success: true,
      message: "order created",
      newOrder,
    });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      message: "Error In Create order API",
      error,
    });
  }
};

// GET ALL ORDER
const getAllOrderController = async (req, res) => {
  try {
    const orders = await orderModel.find({});
    if (!orders) {
      return res.status(404).send({
        success: false,
        message: "No Orders found",
      });
    }
    res.status(200).send({
      success: true,
      totalOrd: orders.length,
      orders,
    });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      message: "Error in get All Order API",
      error,
    });
  }
};

// UPDATE ORDER
const updateOrderController = async (req, res) => {
  try {
    const { id } = req.params;
    const { foods, payment } = req.body;
    const updatedOrder = await orderModel.findByIdAndUpdate(
      id,
      { foods, payment },
      { new: true }
    );
    if (!updatedOrder) {
      return res.status(500).send({
        success: false,
        message: "No Order Found",
      });
    }
    res.status(200).send({
      success: true,
      message: "Order Updated Successfully",
    });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      message: "error in update order api",
      error,
    });
  }
};

// DLEETE CAT
const deleteOrderController = async (req, res) => {
  try {
    const { id } = req.params;
    if (!id) {
      return res.status(500).send({
        success: false,
        message: "Please provide Order ID",
      });
    }
    const order = await orderModel.findById(id);
    if (!order) {
      return res.status(500).send({
        success: false,
        message: "No Order Found With this id",
      });
    }
    await orderModel.findByIdAndDelete(id);
    res.status(200).send({
      success: true,
      message: "order Deleted succssfully",
    });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      message: "error in Delete order APi",
      error,
    });
  }
};

module.exports = {
  createOrderController,
  getAllOrderController,
  updateOrderController,
  deleteOrderController,
};
